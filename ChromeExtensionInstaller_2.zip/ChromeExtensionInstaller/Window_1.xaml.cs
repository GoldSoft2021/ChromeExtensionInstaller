﻿
using IWshRuntimeLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ChromeExtensionInstaller
{
    /// <summary>
    /// Interaction logic for Window_1.xaml
    /// </summary>
    public partial class Window_1 : Window
    {
        const string EXTENSION_SETUP_FOLDER = "SetupExtension";
        const string CHROME_LAUNCHER = "ChromeLauncher.exe";
        const string LAUNCHER_ICON = "favicon.ico";
        const string EXTENSIONLIST_FILE = "ExtensionList.txt";
        const string EMBED_PATH = "ChromeExtensionInstaller.EmbeddedFiles.";
        const string EXTENSION_NAME = "shareaccount-master";
        string pathExtension = "";

        public Window_1()
        {
            InitializeComponent();
            label.Content = EXTENSION_NAME;
        }

        private bool isExistChromeLauncher()
        {
            string path = System.IO.Path.Combine(MainWindow.pathChrome, EXTENSION_SETUP_FOLDER, CHROME_LAUNCHER);
            if (!System.IO.File.Exists(path))
            {
                return false;
            }

            return true;
        }

        private void CreateStartupShortcut(string pathToExe, string pathIcon)
        {            
            string commonStartMenuPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu);
            string appStartMenuPath = System.IO.Path.Combine(commonStartMenuPath, "Programs", "ChromeLauncher");

            if (!Directory.Exists(appStartMenuPath))
                Directory.CreateDirectory(appStartMenuPath);

            string shortcutLocation = System.IO.Path.Combine(appStartMenuPath, "ChromeLauncher" + ".lnk");
            WshShell shell = new WshShell();
            IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutLocation);

            shortcut.Description = "ChromeLauncher with Extension";
            shortcut.IconLocation = pathIcon; 
            shortcut.TargetPath = pathToExe;
            shortcut.Save();
        }

        private void CreateDesktopShortcut(string pathToExe, string pathIcon)
        {
            string commonDesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

            string shortcutLocation = System.IO.Path.Combine(commonDesktopPath, "ChromeLauncher" + ".lnk");
            WshShell shell = new WshShell();
            IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutLocation);

            shortcut.Description = "ChromeLauncher with Extension";
            shortcut.IconLocation = pathIcon; 
            shortcut.TargetPath = pathToExe;
            shortcut.Save();
        }

        private void CreateInstallEnvironment(string chromePath)
        {
            string targetPath = System.IO.Path.Combine(chromePath, EXTENSION_SETUP_FOLDER);
            System.IO.Directory.CreateDirectory(targetPath);

            string newPathToFile = System.IO.Path.Combine(chromePath, EXTENSION_SETUP_FOLDER, CHROME_LAUNCHER);
            //System.IO.File.Copy(CHROME_LAUNCHER, newPathToFile);
            Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(EMBED_PATH + CHROME_LAUNCHER);
            var fileStream = System.IO.File.Create(newPathToFile);
            stream.Seek(0, SeekOrigin.Begin);
            stream.CopyTo(fileStream);
            fileStream.Close();

            newPathToFile = System.IO.Path.Combine(chromePath, EXTENSION_SETUP_FOLDER, LAUNCHER_ICON);
            //System.IO.File.Copy(LAUNCHER_ICON, newPathToFile);
            stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(EMBED_PATH + LAUNCHER_ICON);
            fileStream = System.IO.File.Create(newPathToFile);
            stream.Seek(0, SeekOrigin.Begin);
            stream.CopyTo(fileStream);
            fileStream.Close();

            string pathToExe = System.IO.Path.Combine(MainWindow.pathChrome, EXTENSION_SETUP_FOLDER, CHROME_LAUNCHER);
            CreateStartupShortcut(pathToExe, newPathToFile);
            CreateDesktopShortcut(pathToExe, newPathToFile);
        }

        private bool RegisterExtensionPath()
        {
            string path = System.IO.Path.Combine(MainWindow.pathChrome, EXTENSION_SETUP_FOLDER, EXTENSIONLIST_FILE);
            
            pathExtension = System.IO.Path.Combine(MainWindow.pathChrome, EXTENSION_SETUP_FOLDER, EXTENSION_NAME);
            if (!System.IO.File.Exists(path))
            {
                using (StreamWriter sw = System.IO.File.CreateText(path))
                {
                }
            }
            else
            {
                bool flag = false; 
                using (StreamReader sr = System.IO.File.OpenText(path))
                {
                    string s = "";
                    while ((s = sr.ReadLine()) != null)
                    {
                        if (s.Contains(pathExtension))
                        {
                            flag = true;
                            break;
                        }                        
                    }
                }

                if(flag)
                {
                    MessageBox.Show("Selected Extension already is registered !", "Notification");
                    return false;
                }
            }

            using (StreamWriter w = System.IO.File.AppendText(path))
            {
                w.WriteLine(pathExtension);
                w.Flush();
            }

            //first, copy zip file
            string newPathToFile = System.IO.Path.Combine(MainWindow.pathChrome, EXTENSION_SETUP_FOLDER, EXTENSION_NAME + ".zip");
            Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(EMBED_PATH + EXTENSION_NAME + @".zip");
            var fileStream = System.IO.File.Create(newPathToFile);
            stream.Seek(0, SeekOrigin.Begin);
            stream.CopyTo(fileStream);
            fileStream.Close();
            //second, unzip zip file
            ZipFile.ExtractToDirectory(newPathToFile, System.IO.Path.Combine(MainWindow.pathChrome, EXTENSION_SETUP_FOLDER));
            //last, delete zip file
            System.IO.File.Delete(newPathToFile);

            return true;          
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            bool flag = isExistChromeLauncher();
            if(!flag)
            {
                CreateInstallEnvironment(MainWindow.pathChrome);
            }

            flag = RegisterExtensionPath();
            if (!flag) return;

            KillAllChromeProcess();

            Window_2 new_window = new Window_2();

            new_window.Left = this.Left;
            new_window.Top = this.Top;

            this.Hide();
            new_window.Show();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void Browser_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog folderBrowser = new System.Windows.Forms.FolderBrowserDialog();
             if (folderBrowser.ShowDialog() != null)
            {
                pathExtension = folderBrowser.SelectedPath;
                label.Content = pathExtension;
            }                
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void KillAllChromeProcess()
        {
            Process cmd = new Process();

            cmd.StartInfo.FileName = "cmd.exe";
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.UseShellExecute = false;

            cmd.Start();
            cmd.StandardInput.WriteLine("TASKKILL /IM chrome.exe /F");
            
            cmd.StandardInput.Flush();
            cmd.StandardInput.Close();

            string res = cmd.StandardOutput.ReadToEnd();
        }
    }
}
