﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ChromeExtensionInstaller
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        public static string pathChrome;
        private static string getChromeFolderPath()
        {
            string path = "";
            if (File.Exists("C:\\Program Files(x86)\\Google\\Chrome\\Application\\chrome.exe"))
            {
                path = "C:\\Program Files(x86)\\Google\\Chrome\\Application";
            }
            else if (File.Exists("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"))
            {
                path = "C:\\Program Files\\Google\\Chrome\\Application";
            }
            return path;
        }

        public MainWindow()
        {
            InitializeComponent();

            pathChrome = getChromeFolderPath();
            if (pathChrome.Length == 0)
            {
                MessageBox.Show("You must install Chrome !", "Notification");
                System.Windows.Application.Current.Shutdown();
            }
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            Window_1 new_window = new Window_1();

            new_window.Left = this.Left;
            new_window.Top = this.Top;

            this.Hide();
            new_window.Show();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

    }
}
