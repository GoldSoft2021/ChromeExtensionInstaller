﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChromeLauncher
{
    class Program
    {
        const string EXTENSION_SETUP_FOLDER = "SetupExtension";
        const string EXTENSIONLIST_FILE = "ExtensionList.txt";
        string pathChrome;
        private string getChromeFolderPath()
        {
            string path = "";
            if (File.Exists("C:\\Program Files(x86)\\Google\\Chrome\\Application\\chrome.exe"))
            {
                path = "C:\\Program Files(x86)\\Google\\Chrome\\Application";
            }
            else if (File.Exists("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"))
            {
                path = "C:\\Program Files\\Google\\Chrome\\Application";
            }
            return path;
        }

        private string getExtensionList()
        {
            string extList = "";
            string line;
            int counter = 0;

            string pathExtension = Path.Combine(pathChrome, EXTENSION_SETUP_FOLDER, EXTENSIONLIST_FILE);

            if(!File.Exists(pathExtension))
            {
                return extList;
            }
  
            System.IO.StreamReader file = new System.IO.StreamReader(pathExtension);
            while ((line = file.ReadLine()) != null)
            {
                if (counter > 0) extList += ',';
                extList += line;
                counter++;
            }
            file.Close();

            return extList;
        }

        private void Launch_Extension(string chromePath, string extensionPath)
        {
            Process cmd = new Process();

            cmd.StartInfo.FileName = "cmd.exe";
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.UseShellExecute = false;
            cmd.StartInfo.WorkingDirectory = chromePath;

            cmd.Start();

            string command = "chrome.exe --load-extension=" + "\"" + extensionPath + "\"";
            cmd.StandardInput.WriteLine(command);

            cmd.StandardInput.Flush();
            cmd.StandardInput.Close();
        }

        static void Main(string[] args)
        {
            Program prog = new Program();

            prog.pathChrome = prog.getChromeFolderPath();            
            if (prog.pathChrome.Length == 0)
            {                
                MessageBox.Show("You should install Chrome !", "Notification");
                return;
            }

            string pathExtension = prog.getExtensionList();
            if (pathExtension.Length == 0)
            {
                MessageBox.Show("There is no ExtensionList File !\n You must install Chrome Extensions", "Notification");
                return;
            }
            prog.Launch_Extension(prog.pathChrome, pathExtension);
        }
    }
}
